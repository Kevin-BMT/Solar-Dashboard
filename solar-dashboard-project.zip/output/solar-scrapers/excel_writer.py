"""
Writes scalar values into specific cells of a macro-enabled workbook (.xlsm)
WITHOUT losing the VBA project. openpyxl's keep_vba=True is the magic flag —
without it, saving an .xlsm strips all macros and breaks your snapshot routine.

Also guards against:
  * Workbook open in Excel (PermissionError on save -> clear message)
  * Missing sheet name
  * Missing cell address

Usage:
    writer = WorkbookWriter("C:/path/to/file.xlsm", sheet="Dashboard")
    writer.set("Y30", 30.6)
    writer.set("Y28", 29.4)
    writer.save()
"""

from __future__ import annotations
import logging
from pathlib import Path
from typing import Any

from openpyxl import load_workbook

log = logging.getLogger(__name__)


class WorkbookWriter:
    def __init__(self, path: str | Path, sheet: str):
        self.path = Path(path)
        self.sheet_name = sheet
        if not self.path.exists():
            raise FileNotFoundError(f"Workbook not found: {self.path}")

        # keep_vba=True preserves the VBA project.
        # data_only=False keeps formulas (we never want to flatten them).
        self.wb = load_workbook(self.path, keep_vba=True, data_only=False)

        if sheet not in self.wb.sheetnames:
            raise KeyError(
                f"Sheet '{sheet}' not found. Available: {self.wb.sheetnames}"
            )
        self.ws = self.wb[sheet]
        self._pending: dict[str, Any] = {}

    def set(self, cell: str, value: Any) -> None:
        """Stage a value to be written. Nothing hits disk until save()."""
        self.ws[cell] = value
        self._pending[cell] = value
        log.info("Staged %s!%s = %s", self.sheet_name, cell, value)

    def save(self) -> None:
        """Persist the workbook. Macros are preserved."""
        try:
            self.wb.save(self.path)
        except PermissionError as e:
            raise PermissionError(
                f"Cannot save {self.path} — is it open in Excel? Close it and retry."
            ) from e
        log.info("Saved %s (%d cells updated)", self.path.name, len(self._pending))
