"""
Sineng / EnjoySolar portal scraper — PRODUCTION + CONSUMPTION.

Login flow:
  1. Open login URL
  2. Fill credentials, click Login
  3. Wait for dashboard redirect
  4. Read the "TOP Plants" widget for each plant:
     - Strategy A: Read from tabbed widget (Yield Today / Consumption Today tabs)
     - Strategy B: Read from multi-column row (both values in same row)
     - Strategy C: Navigate to individual plant detail page and read stats
  5. Return {plant_name: {"production": float, "consumption": float}}

Multiple selector strategies are tried in order. If the layout shifts, only
this file needs updating.

Run standalone for debugging:
    python -m portals.sineng --headed --debug
"""

from __future__ import annotations
import logging
import re
from typing import Any

from playwright.sync_api import expect, TimeoutError as PWTimeout

from .base import BasePortal, PortalError

log = logging.getLogger(__name__)


class SinengPortal(BasePortal):
    name = "sineng"

    def login(self) -> None:
        login_url = self.config["login_url"]
        log.info("Navigating to %s", login_url)
        self.page.goto(login_url, wait_until="networkidle")

        # Dismiss cookie banner if present.
        self._dismiss_cookie_banner()

        # Fill credentials.
        self._fill_credentials()

        # Click the Login button.
        login_btn = self.page.locator(
            "button:has-text('Login'), button:has-text('Sign in'), "
            "button:has-text('LOGIN'), .login-btn, button[type=submit]"
        ).first
        login_btn.click()

        # Wait for dashboard URL.
        try:
            self.page.wait_for_url(
                re.compile(r".*/#/dashboard.*"), timeout=self.timeout_ms
            )
        except PWTimeout as e:
            raise PortalError("Login appeared to fail (no dashboard redirect)") from e

        log.info("Login OK — on dashboard")

    def scrape(self) -> dict[str, dict[str, float]]:
        """Return {plant_name: {"production": kWh, "consumption": kWh}}."""
        if "/dashboard" not in self.page.url:
            self.page.goto(self.config["dashboard_url"], wait_until="networkidle")

        self.page.get_by_text("TOP Plants", exact=False).first.wait_for(
            timeout=self.timeout_ms
        )

        results: dict[str, dict[str, float]] = {}
        for site in self.config["sites"]:
            plant_name = site["plant"]
            log.info("  Scraping %s...", plant_name)

            # Try Strategy A first: tabbed widget
            data = self._read_plant_tabbed(plant_name, site)
            if data is None:
                # Strategy B: multi-column row
                data = self._read_plant_row(plant_name, site)
            if data is None:
                # Strategy C: plant detail page
                data = self._read_plant_detail(plant_name, site)
            if data is None:
                raise PortalError(f"All strategies failed for '{plant_name}'")

            results[plant_name] = data
            log.info(
                "  %s → production=%.2f kWh, consumption=%.2f kWh",
                plant_name,
                data["production"],
                data["consumption"],
            )

        return results

    # ------------------------------------------------------------------
    # STRATEGY A: Tabbed widget (Yield Today / Consumption Today tabs)
    # ------------------------------------------------------------------
    def _read_plant_tabbed(
        self, plant_name: str, site: dict
    ) -> dict[str, float] | None:
        """Try reading from a tabbed TOP Plants widget."""
        try:
            production = None
            consumption = None

            # Read production from "Yield Today" tab.
            prod_tab = self.page.get_by_text("Yield Today", exact=False)
            if prod_tab.count() > 0:
                prod_tab.first.click(timeout=2000)
                self.page.wait_for_timeout(500)  # Let tab content render
                val = self._extract_kwh_from_row(plant_name)
                if val is not None:
                    production = val
                    log.debug("Strategy A: production=%.2f from Yield Today tab", val)

            # Read consumption from "Consumption Today" or similar tab.
            for tab_label in (
                "Consumption Today",
                "Consumption",
                "Load Today",
                "Usage Today",
            ):
                cons_tab = self.page.get_by_text(tab_label, exact=False)
                if cons_tab.count() > 0:
                    cons_tab.first.click(timeout=2000)
                    self.page.wait_for_timeout(500)
                    val = self._extract_kwh_from_row(plant_name)
                    if val is not None:
                        consumption = val
                        log.debug(
                            "Strategy A: consumption=%.2f from '%s' tab", val, tab_label
                        )
                        break

            if production is not None and consumption is not None:
                return {"production": production, "consumption": consumption}

            # If we got production but not consumption, fall through to other strategies for consumption.
            if production is not None:
                return {"production": production, "consumption": 0.0}

            return None
        except Exception as e:
            log.debug("Strategy A failed: %s", e)
            return None

    # ------------------------------------------------------------------
    # STRATEGY B: Multi-column row (both values in same row)
    # ------------------------------------------------------------------
    def _read_plant_row(self, plant_name: str, site: dict) -> dict[str, float] | None:
        """Try reading both values from a single row with multiple columns."""
        try:
            row = self.page.locator(
                f"xpath=//*[contains(normalize-space(.), '{plant_name}')]"
            ).first
            row.wait_for(timeout=3000)
            text = row.inner_text()
            log.debug("Strategy B row text: %r", text)

            # Extract all numbers from the row.
            nums = re.findall(r"[\d,]+(?:\.\d+)?", text)
            nums = [float(n.replace(",", "")) for n in nums]

            if len(nums) >= 2:
                # Assume first number = production, second = consumption.
                return {"production": nums[0], "consumption": nums[1]}
            elif len(nums) == 1:
                return {"production": nums[0], "consumption": 0.0}

            return None
        except Exception as e:
            log.debug("Strategy B failed: %s", e)
            return None

    # ------------------------------------------------------------------
    # STRATEGY C: Plant detail page (navigate to each plant's detail view)
    # ------------------------------------------------------------------
    def _read_plant_detail(
        self, plant_name: str, site: dict
    ) -> dict[str, float] | None:
        """Navigate to the plant's detail page and read stats."""
        try:
            # Click on the plant name to open detail view.
            plant_link = self.page.get_by_text(plant_name, exact=True).first
            plant_link.click(timeout=3000)
            self.page.wait_for_timeout(1000)

            # Now on plant detail page — look for Today's Yield/Generation and Consumption.
            production = self._read_stat_from_page(
                "Yield", "Generation", "Production", "Output"
            )
            consumption = self._read_stat_from_page("Consumption", "Load", "Usage")

            # Go back to dashboard.
            self.page.go_back(wait_until="networkidle")
            self.page.wait_for_timeout(500)

            if production is not None or consumption is not None:
                return {
                    "production": production if production is not None else 0.0,
                    "consumption": consumption if consumption is not None else 0.0,
                }

            return None
        except Exception as e:
            log.debug("Strategy C failed: %s", e)
            # Ensure we're back on dashboard.
            if "/dashboard" not in self.page.url:
                self.page.goto(self.config["dashboard_url"], wait_until="networkidle")
            return None

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _extract_kwh_from_row(self, plant_name: str) -> float | None:
        """Extract a kWh value from the row containing plant_name."""
        row = self.page.locator(
            f"xpath=//*[contains(normalize-space(.), '{plant_name}')]"
            "[contains(., 'kWh') or contains(., 'kwh')]"
        ).first

        try:
            row.wait_for(timeout=2000)
            text = row.inner_text()
        except PWTimeout:
            return None

        m = re.search(r"([\d,]+(?:\.\d+)?)\s*\(?\s*k[Ww][Hh]", text)
        if m:
            return float(m.group(1).replace(",", ""))

        nums = re.findall(r"[\d,]+(?:\.\d+)?", text)
        if nums:
            return float(nums[-1].replace(",", ""))

        return None

    def _read_stat_from_page(self, *labels: str) -> float | None:
        """Read a numeric stat from the current page matching any of the given labels."""
        for label in labels:
            try:
                # Look for a label followed by a number.
                el = self.page.locator(
                    f"xpath=//*[contains(normalize-space(.), '{label}')]"
                    "[contains(., 'kWh') or contains(., 'kW') or contains(., 'kwh')]"
                ).first
                text = el.inner_text(timeout=2000)
                m = re.search(r"([\d,]+(?:\.\d+)?)\s*\(?\s*k[Ww][Hh]", text)
                if m:
                    return float(m.group(1).replace(",", ""))
                nums = re.findall(r"[\d,]+(?:\.\d+)?", text)
                if nums:
                    return float(nums[-1].replace(",", ""))
            except Exception:
                continue
        return None

    def _dismiss_cookie_banner(self) -> None:
        for label in ("Accept", "Got it", "OK", "I agree", "Allow all"):
            btn = self.page.get_by_role("button", name=re.compile(label, re.I))
            try:
                if btn.first.is_visible(timeout=1500):
                    btn.first.click()
                    log.debug("Dismissed cookie banner via '%s'", label)
                    return
            except (PWTimeout, Exception):
                continue

    def _fill_credentials(self) -> None:
        candidates_user = [
            self.page.get_by_placeholder(
                re.compile(r"account|user(name)?|email", re.I)
            ),
            self.page.locator("input[type='text']").first,
        ]
        candidates_pass = [
            self.page.get_by_placeholder(re.compile(r"password", re.I)),
            self.page.locator("input[type='password']").first,
        ]
        if not self._fill_first_visible(candidates_user, self.username):
            raise PortalError("Could not locate the username field")
        if not self._fill_first_visible(candidates_pass, self.password):
            raise PortalError("Could not locate the password field")

    def _fill_first_visible(self, locators: list, value: str) -> bool:
        for loc in locators:
            try:
                if loc.first.is_visible(timeout=2000):
                    loc.first.fill(value)
                    return True
            except (PWTimeout, Exception):
                continue
        return False

    def _click_if_present(self, text: str) -> None:
        try:
            self.page.get_by_text(text, exact=False).first.click(timeout=2000)
        except (PWTimeout, Exception):
            pass


# ----------------------------------------------------------------------
# Standalone debugger:  python -m portals.sineng --headed
# ----------------------------------------------------------------------
if __name__ == "__main__":
    import argparse
    import os
    import sys
    from pathlib import Path

    import yaml
    from dotenv import load_dotenv

    logging.basicConfig(
        level=logging.INFO, format="%(asctime)s  %(levelname)s  %(message)s"
    )

    parser = argparse.ArgumentParser()
    parser.add_argument("--headed", action="store_true", help="show the browser")
    parser.add_argument("--debug", action="store_true", help="save error screenshots")
    args = parser.parse_args()

    load_dotenv()
    cfg = yaml.safe_load(
        Path(__file__).parent.parent.joinpath("config.yaml").read_text()
    )
    sineng_cfg = cfg["portals"]["sineng"]
    user = os.environ.get("SINENG_USERNAME")
    pw = os.environ.get("SINENG_PASSWORD")
    if not user or not pw:
        sys.exit("Set SINENG_USERNAME and SINENG_PASSWORD in .env")

    with SinengPortal(
        sineng_cfg, user, pw, headless=not args.headed, debug=args.debug
    ) as p:
        print(p.run_with_retries())
