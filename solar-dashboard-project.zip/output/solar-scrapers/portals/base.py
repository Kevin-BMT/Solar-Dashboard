"""
Base class for all portal scrapers.
Each portal subclass implements `scrape()` and returns a dict:
    { "Plant Name": {"production": float, "consumption": float}, ... }
The orchestrator (scrape.py) then maps plant names to workbook cells.
"""

from __future__ import annotations
import logging
import time
from abc import ABC, abstractmethod
from typing import Any

from playwright.sync_api import Browser, BrowserContext, Page, sync_playwright

log = logging.getLogger(__name__)


class PortalError(Exception):
    """Raised when a portal scrape fails after retries."""


class BasePortal(ABC):
    name: str = "base"

    def __init__(
        self,
        config: dict[str, Any],
        username: str,
        password: str,
        headless: bool = True,
        debug: bool = False,
        timeout_ms: int = 30_000,
    ):
        self.config = config
        self.username = username
        self.password = password
        self.headless = headless
        self.debug = debug
        self.timeout_ms = timeout_ms

    # ---- context manager so callers can `with SinengPortal(...) as p:` ----
    def __enter__(self) -> "BasePortal":
        self._pw = sync_playwright().start()
        self.browser: Browser = self._pw.chromium.launch(headless=self.headless)
        self.context: BrowserContext = self.browser.new_context(
            viewport={"width": 1600, "height": 900},
            locale="en-GB",
        )
        self.context.set_default_timeout(self.timeout_ms)
        self.page: Page = self.context.new_page()
        return self

    def __exit__(self, exc_type, exc, tb):
        try:
            if exc and self.debug:
                shot = f"logs/{self.name}_error_{int(time.time())}.png"
                self.page.screenshot(path=shot, full_page=True)
                log.error("Saved error screenshot: %s", shot)
        finally:
            self.context.close()
            self.browser.close()
            self._pw.stop()

    # ---- subclasses implement these ----
    @abstractmethod
    def login(self) -> None: ...

    @abstractmethod
    def scrape(self) -> dict[str, dict[str, float]]:
        """Return {plant_name: {"production": kWh, "consumption": kWh}}."""

    # ---- helpers ----
    def run_with_retries(
        self, attempts: int = 3, backoff_s: float = 5.0
    ) -> dict[str, dict[str, float]]:
        last_err: Exception | None = None
        for i in range(1, attempts + 1):
            try:
                log.info("[%s] attempt %d/%d", self.name, i, attempts)
                self.login()
                return self.scrape()
            except Exception as e:  # noqa: BLE001
                last_err = e
                log.warning("[%s] attempt %d failed: %s", self.name, i, e)
                if i < attempts:
                    time.sleep(backoff_s * i)
        raise PortalError(f"[{self.name}] all {attempts} attempts failed") from last_err
