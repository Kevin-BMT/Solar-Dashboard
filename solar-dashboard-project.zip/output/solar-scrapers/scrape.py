"""
Main entry point.

Reads config.yaml + .env, scrapes each enabled portal, writes scraped values
into the .xlsm workbook (macros preserved), logs everything to logs/.
Optionally pushes the updated .xlsm to GitHub so the web dashboard refreshes.

Run:
    python scrape.py                      # all enabled portals, headless
    python scrape.py --portal sineng      # just one portal
    python scrape.py --headed --debug     # watch the browser, save error shots
    python scrape.py --dry-run            # scrape but do NOT write workbook
    python scrape.py --no-push            # write workbook but skip GitHub push
"""

from __future__ import annotations

import argparse
import logging
import os
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime
from pathlib import Path

import yaml
from dotenv import load_dotenv

from excel_writer import WorkbookWriter
from portals.base import PortalError
from portals.sineng import SinengPortal
from portals.deye import DeyePortal

ROOT = Path(__file__).parent

# Portal name -> (class, env var prefix)
PORTAL_REGISTRY = {
    "sineng": (SinengPortal, "SINENG"),
    "deye": (DeyePortal, "DEYE"),
}


def setup_logging(debug: bool) -> Path:
    ROOT.joinpath("logs").mkdir(exist_ok=True)
    log_path = ROOT / "logs" / f"{datetime.now():%Y-%m-%d}.log"
    level = logging.DEBUG if debug else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s  %(levelname)-7s  %(name)s  %(message)s",
        handlers=[
            logging.FileHandler(log_path, encoding="utf-8"),
            logging.StreamHandler(sys.stdout),
        ],
    )
    return log_path


def scrape_portal(
    name: str, portal_cfg: dict, headless: bool, debug: bool
) -> dict[str, dict[str, float]]:
    cls, env_prefix = PORTAL_REGISTRY[name]
    user = os.environ.get(f"{env_prefix}_USERNAME")
    pw = os.environ.get(f"{env_prefix}_PASSWORD")
    if not user or not pw:
        raise PortalError(
            f"Missing {env_prefix}_USERNAME / {env_prefix}_PASSWORD in .env"
        )

    with cls(portal_cfg, user, pw, headless=headless, debug=debug) as portal:
        return portal.run_with_retries()


def _flatten_results(
    by_portal: dict[str, dict[str, dict[str, float]]],
) -> dict[str, dict[str, float]]:
    """Flatten portal results into {plant_name: {"production": x, "consumption": y}}."""
    out: dict[str, dict[str, float]] = {}
    for vals in by_portal.values():
        out.update(vals)
    return out


def write_to_workbook(
    wb_path: str,
    wb_sheet: str,
    site_cell_map: dict[str, dict[str, str]],
    results: dict[str, dict[str, float]],
) -> int:
    """Write scraped values to the workbook. Returns number of cells written."""
    writer = WorkbookWriter(wb_path, wb_sheet)
    count = 0
    for plant, values in results.items():
        cells = site_cell_map.get(plant, {})
        prod_cell = cells.get("production_cell")
        cons_cell = cells.get("consumption_cell")

        if prod_cell and "production" in values:
            writer.set(prod_cell, values["production"])
            count += 1
        if cons_cell and "consumption" in values:
            writer.set(cons_cell, values["consumption"])
            count += 1

    writer.save()
    return count


def push_to_github(cfg: dict, wb_path: str, log: logging.Logger) -> bool:
    """Git add, commit, and push the updated workbook to GitHub."""
    if not cfg.get("enabled", False):
        return False

    token = os.environ.get("GITHUB_TOKEN")
    if not token:
        log.warning(
            "github.enabled=true but GITHUB_TOKEN not set in .env — skipping push"
        )
        return False

    owner = cfg["repo_owner"]
    repo = cfg["repo_name"]
    branch = cfg.get("branch", "main")
    xlsm_path = cfg["xlsm_path"]
    commit_msg = cfg.get("commit_message", "Auto-update: scraped solar data")

    tmpdir = Path(tempfile.mkdtemp(prefix="solar_push_"))
    remote_url = f"https://{token}@github.com/{owner}/{repo}.git"

    try:
        log.info("Cloning %s/%s for push...", owner, repo)
        subprocess.run(
            [
                "git",
                "clone",
                "--depth",
                "1",
                "--branch",
                branch,
                remote_url,
                str(tmpdir),
            ],
            check=True,
            capture_output=True,
            text=True,
        )

        dest = tmpdir / xlsm_path
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(wb_path, dest)

        log.info("Committing and pushing...")
        subprocess.run(
            ["git", "config", "user.email", "solar-scraper@local"],
            cwd=tmpdir,
            check=True,
        )
        subprocess.run(
            ["git", "config", "user.name", "Solar Scraper"], cwd=tmpdir, check=True
        )
        subprocess.run(["git", "add", xlsm_path], cwd=tmpdir, check=True)
        subprocess.run(
            ["git", "commit", "-m", commit_msg],
            cwd=tmpdir,
            check=True,
            capture_output=True,
            text=True,
        )
        subprocess.run(
            ["git", "push", "origin", branch],
            cwd=tmpdir,
            check=True,
            capture_output=True,
            text=True,
        )

        log.info("Pushed to %s/%s branch %s", owner, repo, branch)
        return True

    except subprocess.CalledProcessError as e:
        log.error("GitHub push failed: %s", e.stderr or e.stdout)
        return False
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Scrape solar portals into the Dashboard workbook."
    )
    parser.add_argument(
        "--portal",
        choices=PORTAL_REGISTRY.keys(),
        help="Run only one portal (default: all enabled)",
    )
    parser.add_argument("--headed", action="store_true", help="Show browser window")
    parser.add_argument(
        "--debug", action="store_true", help="Verbose logs + error screenshots"
    )
    parser.add_argument(
        "--dry-run", action="store_true", help="Do not write to workbook"
    )
    parser.add_argument(
        "--no-push", action="store_true", help="Skip GitHub push even if enabled"
    )
    args = parser.parse_args()

    load_dotenv(ROOT / ".env")
    setup_logging(args.debug)
    log = logging.getLogger("scrape")

    cfg = yaml.safe_load((ROOT / "config.yaml").read_text(encoding="utf-8"))
    wb_path = cfg["workbook"]["path"]
    wb_sheet = cfg["workbook"]["sheet"]

    targets = (
        [args.portal]
        if args.portal
        else [n for n, c in cfg["portals"].items() if c.get("enabled")]
    )
    if not targets:
        log.error("No portals enabled in config.yaml")
        return 2

    # ---- Scrape phase ----
    all_results: dict[str, dict[str, dict[str, float]]] = {}
    site_cell_map: dict[str, dict[str, str]] = {}
    for portal_name in targets:
        portal_cfg = cfg["portals"][portal_name]
        log.info("==== %s ====", portal_name.upper())
        try:
            values = scrape_portal(
                portal_name, portal_cfg, headless=not args.headed, debug=args.debug
            )
        except PortalError as e:
            log.error("[%s] FAILED: %s", portal_name, e)
            continue
        all_results[portal_name] = values
        for site in portal_cfg["sites"]:
            cell_entry = {"production_cell": site.get("production_cell")}
            if site.get("consumption_cell"):
                cell_entry["consumption_cell"] = site["consumption_cell"]
            site_cell_map[site["plant"]] = cell_entry

    if not all_results:
        log.error("All portals failed.")
        return 1

    flat = _flatten_results(all_results)

    # ---- Dry run ----
    if args.dry_run:
        log.info("Dry run — workbook NOT written. Values that would be written:")
        for plant, values in flat.items():
            cells = site_cell_map.get(plant, {})
            for metric in ("production", "consumption"):
                cell = cells.get(f"{metric}_cell", "?")
                val = values.get(metric, "N/A")
                log.info("  %s -> %s!%s = %s (%s)", plant, wb_sheet, cell, val, metric)
        return 0

    # ---- Write phase ----
    try:
        count = write_to_workbook(wb_path, wb_sheet, site_cell_map, flat)
        log.info("Done. Wrote %d values to %s", count, wb_path)
    except Exception as e:
        log.error("Failed to write workbook: %s", e)
        return 1

    # ---- GitHub push ----
    if not args.no_push:
        gh_cfg = cfg.get("github", {})
        if gh_cfg.get("enabled", False):
            push_to_github(gh_cfg, wb_path, log)
        else:
            log.info(
                "GitHub push disabled in config.yaml — set github.enabled=true to enable"
            )

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
