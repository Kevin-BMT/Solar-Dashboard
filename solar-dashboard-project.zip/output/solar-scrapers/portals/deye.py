"""
DeyeCloud portal scraper — SCAFFOLD.

Not yet implemented. This is a placeholder for when you're ready to add
DeyeCloud as the second portal.

The DeyeCloud login flow is expected to be:
  1. Open https://www.deyecloud.com/login
  2. Fill email + password
  3. Navigate to the station/plant overview
  4. Read today's generation and consumption per station

When you're ready, implement the `login()` and `scrape()` methods below,
then enable it in config.yaml (set `deye.enabled: true`) and add your
credentials to .env (DEYE_USERNAME / DEYE_PASSWORD).

Run standalone for debugging:
    python -m portals.deye --headed --debug
"""

from __future__ import annotations
import logging
import re
from typing import Any

from playwright.sync_api import TimeoutError as PWTimeout

from .base import BasePortal, PortalError

log = logging.getLogger(__name__)


class DeyePortal(BasePortal):
    name = "deye"

    def login(self) -> None:
        login_url = self.config["login_url"]
        log.info("Navigating to %s", login_url)
        self.page.goto(login_url, wait_until="networkidle")

        # TODO: Dismiss cookie/consent banners if present.
        self._dismiss_cookie_banner()

        # TODO: Fill credentials — adjust selectors after inspecting the login page.
        # DeyeCloud typically uses email + password fields.
        candidates_user = [
            self.page.get_by_placeholder(re.compile(r"email|account|user", re.I)),
            self.page.locator("input[type='email']").first,
            self.page.locator("input[type='text']").first,
        ]
        candidates_pass = [
            self.page.get_by_placeholder(re.compile(r"password", re.I)),
            self.page.locator("input[type='password']").first,
        ]
        if not self._fill_first_visible(candidates_user, self.username):
            raise PortalError("Could not locate the email/username field on DeyeCloud")
        if not self._fill_first_visible(candidates_pass, self.password):
            raise PortalError("Could not locate the password field on DeyeCloud")

        # TODO: Click login button — adjust text/selector after inspection.
        login_btn = self.page.locator(
            "button:has-text('Login'), button:has-text('Sign in'), "
            "button:has-text('Log in'), button[type=submit], .login-btn"
        ).first
        login_btn.click()

        # TODO: Wait for redirect — adjust URL pattern after inspection.
        try:
            self.page.wait_for_url(
                re.compile(r".*deyecloud.*"), timeout=self.timeout_ms
            )
        except PWTimeout as e:
            raise PortalError(
                "Login appeared to fail (no redirect from login page)"
            ) from e

        log.info("Login OK — on DeyeCloud")

    def scrape(self) -> dict[str, dict[str, float]]:
        """
        Return {station_name: {"production": kWh, "consumption": kWh}}.

        TODO: Implement after inspecting the DeyeCloud dashboard.
        Typical approaches:
          - The overview page may list all stations with today's kWh.
          - Or you may need to click into each station's detail page.
          - DeyeCloud often has a "Data Report" or "Statistics" section
            with downloadable CSV — that's the most reliable path.
        """
        raise PortalError(
            "DeyeCloud scraper not yet implemented. Inspect the portal and update this file."
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _dismiss_cookie_banner(self) -> None:
        for label in ("Accept", "Got it", "OK", "I agree", "Allow all", "Agree"):
            btn = self.page.get_by_role("button", name=re.compile(label, re.I))
            try:
                if btn.first.is_visible(timeout=1500):
                    btn.first.click()
                    log.debug("Dismissed cookie banner via '%s'", label)
                    return
            except (PWTimeout, Exception):
                continue

    def _fill_first_visible(self, locators: list, value: str) -> bool:
        for loc in locators:
            try:
                if loc.first.is_visible(timeout=2000):
                    loc.first.fill(value)
                    return True
            except (PWTimeout, Exception):
                continue
        return False


# ----------------------------------------------------------------------
# Standalone debugger
# ----------------------------------------------------------------------
if __name__ == "__main__":
    import argparse
    import os
    import sys
    from pathlib import Path

    import yaml
    from dotenv import load_dotenv

    logging.basicConfig(
        level=logging.INFO, format="%(asctime)s  %(levelname)s  %(message)s"
    )

    parser = argparse.ArgumentParser()
    parser.add_argument("--headed", action="store_true", help="show the browser")
    parser.add_argument("--debug", action="store_true", help="save error screenshots")
    args = parser.parse_args()

    load_dotenv()
    cfg = yaml.safe_load(
        Path(__file__).parent.parent.joinpath("config.yaml").read_text()
    )
    deye_cfg = cfg["portals"]["deye"]
    user = os.environ.get("DEYE_USERNAME")
    pw = os.environ.get("DEYE_PASSWORD")
    if not user or not pw:
        sys.exit("Set DEYE_USERNAME and DEYE_PASSWORD in .env")

    with DeyePortal(
        deye_cfg, user, pw, headless=not args.headed, debug=args.debug
    ) as p:
        print(p.run_with_retries())
